import os
import json
from gimpfu import *

amount = "/100"
output = "C:\\Users\\fsfor\\Downloads\\SCG\\GIMP\\Cards"
attacks = "C:\\Users\\fsfor\\Downloads\\SCG\\attacks.txt"

def find_group(image, group_name):
    for layer in image.layers:
        if pdb.gimp_item_is_group(layer) and layer.name == group_name:
            return layer
    return None

def create_text_layer(image, parent_group, name, text):
    layer = pdb.gimp_text_layer_new(image, text)
    pdb.gimp_item_set_name(layer, name)
    pdb.gimp_image_insert_layer(image, layer, parent_group, -1)
    return layer

def enable_child_layer(parent_group, child_name):
    for layer in parent_group.children:
        if layer.name == child_name:
            layer.visible = True

def generate_cards(template_path, character_stats_path, save_format):
    # Open template image
    template_image = pdb.gimp_file_load(template_path, template_path)

    output_directory = output

    # Open attacks.txt file and load the JSON data
    with open(attacks, 'r') as attacks_file:
        attacks_data = json.load(attacks_file)

    # Open character stats file and process each line separately
    with open(character_stats_path, 'r') as f:
        index = 1
        for line_number, line in enumerate(f, 1):
            # Load JSON object from the current line
            character_stats = json.loads(line)

            # Extract character name and stats
            character_name = list(character_stats.keys())[0]
            stats = list(character_stats.values())[0]

            # Duplicate template image
            card_image = pdb.gimp_image_duplicate(template_image)

            # Find or create Stats group
            stats_group = find_group(card_image, "Stats")
            if stats_group is None:
                stats_group = pdb.gimp_layer_group_new(card_image)
                pdb.gimp_item_set_name(stats_group, "Stats")
                pdb.gimp_image_insert_layer(card_image, stats_group, None, -1)

            # Find or create Base group within Stats group
            base_group = find_group(stats_group, "Base")
            if base_group is None:
                base_group = pdb.gimp_layer_group_new(card_image)
                pdb.gimp_item_set_name(base_group, "Base")
                pdb.gimp_image_insert_layer(card_image, base_group, stats_group, -1)

            # Find or create text layers within Base group
            for character_name, stats in character_stats.items():
                # Extract HP, DMG, and NRG values based on rarity
                for rarity, stats_dict in stats["stats"].items():
                    hp_value = str(stats_dict.get("hp", ""))
                    dmg_value = str(stats_dict.get("dmg", ""))
                    nrg_value = str(stats_dict.get("nrg", ""))
                    break  # Only extract values for the first rarity found

                # Define text layer names
                text_layer_names = ["NameTXT", "HPTXT", "DMGTXT", "NRGTXT", "AmountTXT"]

                for i, text_layer_name in enumerate(text_layer_names):
                    if text_layer_name == "AmountTXT":
                        value = str(index) + amount
                    else:
                        value = character_name if text_layer_name == "NameTXT" else ""
                        if text_layer_name == "HPTXT":
                            value = hp_value
                        elif text_layer_name == "DMGTXT":
                            value = dmg_value
                        elif text_layer_name == "NRGTXT":
                            value = nrg_value

                    text_layer = None
                    for layer in base_group.layers:
                        if pdb.gimp_item_is_text_layer(layer) and layer.name == text_layer_name:
                            text_layer = layer
                            break
                    if text_layer is None:
                        text_layer = create_text_layer(card_image, base_group, text_layer_name, value)
                    else:
                        pdb.gimp_text_layer_set_text(text_layer, value)

            # Find or create Rarity group
            rarity_group = find_group(card_image, "Rarity")
            if rarity_group is None:
                rarity_group = pdb.gimp_layer_group_new(card_image)
                pdb.gimp_item_set_name(rarity_group, "Rarity")
                pdb.gimp_image_insert_layer(card_image, rarity_group, None, -1)

            # Find or create RarityBG group
            raritybg_group = find_group(card_image, "RarityBG")
            if raritybg_group is None:
                raritybg_group = pdb.gimp_layer_group_new(card_image)
                pdb.gimp_item_set_name(raritybg_group, "RarityBG")
                pdb.gimp_image_insert_layer(card_image, raritybg_group, None, -1)

            # Process each character's stats to enable child layers in the Rarity group
            for character_name, stats in character_stats.items():
                if "stats" in stats:
                    stats_info = stats["stats"]
                    for rarity, stats_dict in stats_info.items():
                        enable_child_layer(rarity_group, rarity)
                        enable_child_layer(raritybg_group, rarity+"Z")

            # Update the text layers for basic and special attacks
            basic_attack_description = ""
            special_attack_description = ""

            # Initialize attack keys with default values
            basic_attack_key = ""
            special_attack_key = ""

            # Check if "basic attack" and "special attack" exist in stats
            if "basic attack" in stats and stats["basic attack"] in attacks_data["Basic"]:
                basic_attack_key = stats["basic attack"]
                basic_attack_value = attacks_data["Basic"][basic_attack_key]
                basic_attack_description = "{}".format(basic_attack_value['Description'])

            if "special attack" in stats and stats["special attack"] in attacks_data["Special"]:
                special_attack_key = stats["special attack"]
                special_attack_value = attacks_data["Special"][special_attack_key]
                special_attack_description = "{}".format(special_attack_value['Description'])

            # Update text layers with attack descriptions
            basic_text_layer = None
            special_text_layer = None

            for layer in base_group.layers:
                if pdb.gimp_item_is_text_layer(layer):
                    if layer.name == "BasicTXT":
                        basic_text_layer = layer
                    elif layer.name == "SpecialTXT":
                        special_text_layer = layer

            # Update text layers with attack descriptions
            if basic_text_layer:
                pdb.gimp_text_layer_set_text(basic_text_layer, basic_attack_description)

            if special_text_layer:
                if not stats["special attack"]:
                    pdb.gimp_text_layer_set_text(special_text_layer, "")
                else:
                    pdb.gimp_text_layer_set_text(special_text_layer, special_attack_description)

            # Update text layers with attack titles and descriptions
            basic_title_layer = None
            special_title_layer = None

            for layer in base_group.layers:
                if pdb.gimp_item_is_text_layer(layer):
                    if layer.name == "BasicTitleTXT":
                        basic_title_layer = layer
                    elif layer.name == "SpecialTitleTXT":
                        special_title_layer = layer

           # Update text layers with attack titles
            if basic_title_layer:
                pdb.gimp_text_layer_set_text(basic_title_layer, basic_attack_key)
                enable_child_layer(base_group, "Basic")

            if special_title_layer:
                pdb.gimp_text_layer_set_text(special_title_layer, special_attack_key)
                if special_attack_key:
                    enable_child_layer(base_group, "Special")

            # Save the modified image
            if save_format == 'PNG':
                # Merge all visible layers into one
                merged_layer = pdb.gimp_image_merge_visible_layers(card_image, CLIP_TO_IMAGE)

                output_path = os.path.join(output_directory, "{}. {}.png".format(index, character_name))
                pdb.file_png_save_defaults(card_image, merged_layer, output_path, output_path)
            elif save_format == 'XCF':
                output_path = os.path.join(output_directory, "{}. {}.xcf".format(index, character_name))
                pdb.gimp_xcf_save(0, card_image, card_image.active_layer, output_path, output_path)
            else:
                print("Invalid save format provided.")
            index += 1

    # Close template image
    pdb.gimp_image_delete(template_image)

# Register the function with GIMP
register(
    "python_fu_generate_cards",
    "Generate cards from character stats",
    "Generate cards from character stats",
    "Author Name",
    "Author Name",
    "2024",
    "<Image>/Filters/Generate Cards",
    "",
    [
        (PF_FILE, "template_path", "Template image", ""),
        (PF_FILE, "character_stats_path", "Character stats file", ""),
        (PF_RADIO, "save_format", "Save Format", "PNG", (("PNG", "PNG"), ("XCF", "XCF")))
    ],
    [],
    generate_cards)

# Main function
def main():
    pass

# Calling main function
if __name__ == '__main__':
    main()
