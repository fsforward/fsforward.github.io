import os
from gimpfu import *

def flatten_image(image):
    # Flatten image by merging visible layers
    merged_layer = pdb.gimp_image_merge_visible_layers(image, CLIP_TO_IMAGE)
    return merged_layer

def convert_xcf_to_png(xcf_path, output_directory):
    # Load XCF file
    xcf_image = pdb.gimp_xcf_load(1, xcf_path, xcf_path)

    # Flatten the image
    merged_layer = flatten_image(xcf_image)

    # Save as PNG
    png_path = os.path.join(output_directory, os.path.splitext(os.path.basename(xcf_path))[0] + ".png")
    pdb.file_png_save_defaults(xcf_image, merged_layer, png_path, png_path)

    # Close XCF image
    pdb.gimp_image_delete(xcf_image)

def convert_xcfs_in_directory(directory, output_directory):
    # Ensure output directory exists
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    # Iterate over files in directory
    for filename in os.listdir(directory):
        if filename.endswith(".xcf"):
            xcf_path = os.path.join(directory, filename)
            convert_xcf_to_png(xcf_path, output_directory)

# Register the function with GIMP
register(
    "python_fu_convert_xcfs_to_pngs",
    "Convert XCF files to PNGs",
    "Convert XCF files to PNGs",
    "Sarah",
    "Sarah",
    "2024",
    "<Image>/Filters/Convert XCFs to PNGs",
    "",
    [
        (PF_DIRNAME, "directory", "Directory containing XCF files", ""),
        (PF_DIRNAME, "output_directory", "Output directory for PNG files", ""),
    ],
    [],
    convert_xcfs_in_directory)

# Main function
def main():
    pass

# Calling main function
if __name__ == '__main__':
    main()
