Uh-oh, 'Conveyor Waffle' has been flagged as a virus!

When the game is exported to a .exe, it will trigger 2 false positive detections. Upon compression using UPX, the file size shrinks from 3MB to a mere 300KB, but unfortunately, this compressed .exe will be flagged with 4 false positives.

Remember, never fully trust anything online. It's crucial to conduct your own research. However, I assure you of its safety.

For added assurance, I will (soon) include the project source so you can compile it yourself if you're skeptical and proficient in doing so.

To ensure your safety, only download 'Conveyor Waffle' from fsforward.com. Any other source may pose risks beyond my control.

Despite these precautions, enjoy playing the game. 'Conveyor Waffle' is currently in its pre-alpha stage, with both the title and gameplay subject to change.