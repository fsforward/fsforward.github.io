#include <raylib.h>

int main()
{
    int windowWidth{800};
    int windowHeight{450};
    InitWindow(windowWidth, windowHeight, "My First Raylib \"Game\" | By fsForward");

    // Circle
    int movementSpeed{5};
    int circleXPosition{windowWidth / 2};
    int circleYPosition{windowHeight / 2};
    float circleRadius{25.f};
    
    // Cube
    int cubeMoveSpeed{10};
    int cubeXPosition{650};
    int cubeYPosition{250};
    int cubeSize{50};

    bool collisionWithCube{false};

    SetTargetFPS(60);
    while (!WindowShouldClose())
    {
        // Circle collision/corners
        int xCircleL{circleXPosition - (int)circleRadius};
        int xCircleR{circleXPosition + (int)circleRadius};
        int yCircleT{circleYPosition - (int)circleRadius};
        int yCircleB{circleYPosition + (int)circleRadius};

        // Cube collision/corners
        int xCubeL{cubeXPosition};
        int xCubeR{cubeXPosition + cubeSize};
        int yCubeT{cubeYPosition};
        int yCubeB{cubeYPosition + cubeSize};

       collisionWithCube = (xCircleL <= xCubeR) && (xCircleR >= xCubeL) && (yCircleT <= yCubeB) && (yCircleB >= yCubeT);

        BeginDrawing();
        ClearBackground(WHITE);

        if (collisionWithCube) DrawText("Game Over!", windowWidth / 2, windowHeight / 2, 25, RED);
        else {
            if (IsKeyDown(KEY_W) && yCircleT > 0) circleYPosition -= movementSpeed;
            if (IsKeyDown(KEY_S) && yCircleB < windowHeight) circleYPosition += movementSpeed;
            if (IsKeyDown(KEY_D) && xCircleR < windowWidth) circleXPosition += movementSpeed;
            if (IsKeyDown(KEY_A) && xCircleL > 0) circleXPosition -= movementSpeed;

            cubeYPosition += cubeMoveSpeed;
            if (cubeYPosition >= windowHeight - cubeSize || cubeYPosition < 0) cubeMoveSpeed = -cubeMoveSpeed;

            DrawRectangle(cubeXPosition, cubeYPosition, cubeSize, cubeSize, RED);
            DrawCircle(circleXPosition, circleYPosition, circleRadius, BLUE);
        }

        EndDrawing();
    }

    CloseWindow();
    return 0;
} 