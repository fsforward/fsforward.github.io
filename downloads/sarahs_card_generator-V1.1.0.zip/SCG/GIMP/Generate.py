import sys
sys.path.append('C:\\Users\\fsfor\\Downloads\\SCG\\GIMP')

import CardMaker
CardMaker.generate_cards('C:\\Users\\fsfor\\Downloads\\SCG\\GIMP\\template.xcf', 'C:\\Users\\fsfor\\Downloads\\SCG\\character_stats.json', 'PNG') # PNG or XCF



import sys
sys.path.append('C:\\Users\\fsfor\\Documents\\py\\GIMP')

import xcf2png
xcf2png.convert_xcfs_in_directory('C:\\Users\\fsfor\\Downloads\\SCG\\GIMP\\Cards', 'C:\\Users\\fsfor\\Downloads\\SCG\\GIMP\\Cards\\png')