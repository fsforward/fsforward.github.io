import json
import os
import shutil
import random
from gimpfu import *

def ensure_directory_exists(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)

def get_character_images(character_images_dir):
    used_images_dir = os.path.join(character_images_dir, 'Used')
    ensure_directory_exists(used_images_dir)
    
    images = {}
    for filename in os.listdir(character_images_dir):
        if filename.endswith(".png"):
            parts = filename[:-4].split(' ', 2)
            if len(parts) == 3:
                number, name, rarity = parts
                key = "{} {}".format(name, rarity)
                if key not in images:
                    images[key] = []
                images[key].append(filename)
    return images, used_images_dir

def move_used_image(character_images_dir, filename):
    used_images_dir = os.path.join(character_images_dir, 'Used')
    shutil.move(os.path.join(character_images_dir, filename), os.path.join(used_images_dir, filename))

def paste_character_image(card_image, character_images, name, rarity, character_images_dir):
    image_list = character_images.get("{} {}".format(name, rarity), [])
    if not image_list:
        print("No image found for {} {}".format(name, rarity))
        return

    image_filename = random.choice(image_list)
    image_path = os.path.join(character_images_dir, image_filename)

    if not os.path.exists(image_path):
        print("Image file not found at path: {}".format(image_path))
        return

    image_to_paste = pdb.gimp_file_load(image_path, image_path)
    design_group = next((l for l in card_image.layers if l.name == "Design"), None)
    if design_group:
        image_layer = next((l for l in design_group.layers if l.name == "Image"), None)
        if image_layer:
            image_to_paste_layer = image_to_paste.active_layer
            pdb.gimp_edit_copy(image_to_paste_layer)
            floating_sel = pdb.gimp_edit_paste(image_layer, True)
            pdb.gimp_floating_sel_anchor(floating_sel)
            pdb.gimp_image_delete(image_to_paste)
            move_used_image(character_images_dir, image_filename)

def merge_layers(image):
    return pdb.gimp_image_merge_visible_layers(image, CLIP_TO_IMAGE)

def set_layer_text(layer, text):
    if layer:
        pdb.gimp_text_layer_set_text(layer, text)

def show_rarity_layer(rarity_group, rarity_name):
    if rarity_group:
        for layer in rarity_group.layers:
            pdb.gimp_item_set_visible(layer, layer.name == rarity_name)

def show_attack_group(attacks_group, has_basic, has_special):
    if attacks_group:
        for layer in attacks_group.layers:
            if layer.name.startswith("B_Attack"):
                pdb.gimp_item_set_visible(layer, has_basic and not has_special)
            if layer.name.startswith("BS_Attack"):
                pdb.gimp_item_set_visible(layer, has_special)

def update_text_layers(txt_group, name, stats, current_number, total_count):
    layers = {layer.name: layer for layer in txt_group.layers}
    set_layer_text(layers.get('Name'), name)
    set_layer_text(layers.get('HP'), str(stats.get('hp', 'N/A')))
    dmg_value = str(stats.get('dmg', 'N/A'))
    set_layer_text(layers.get('DMG'), dmg_value)
    set_layer_text(layers.get('NRG'), str(stats.get('nrg', 'N/A')))
    set_layer_text(layers.get('Cards'), "{} / {}".format(current_number, total_count))
    return int(dmg_value) if dmg_value.isdigit() else 0

def update_attack_layers(attacks_group, attack_type, attack_name, attack_info, dmg_value):
    if attacks_group:
        basic_attack_group = next((l for l in attacks_group.layers if l.name == "B_Attack"), None)
        if basic_attack_group and attack_type == 'Basic':
            set_layer_text(next((l for l in basic_attack_group.layers if l.name == "B_Name"), None), attack_name)
            set_layer_text(next((l for l in basic_attack_group.layers if l.name == "B_Description"), None), attack_info.get('Description', ''))
            set_layer_text(next((l for l in basic_attack_group.layers if l.name == "B_DMG"), None), str(dmg_value))

        special_attack_group = next((l for l in attacks_group.layers if l.name == "BS_Attack"), None)
        if special_attack_group:
            basic_percentage = 0.45
            if attack_type == 'Basic':
                basic_layer = next((l for l in special_attack_group.layers if l.name == "Basic"), None)
                if basic_layer:
                    set_layer_text(next((l for l in basic_layer.layers if l.name == "BS_B_Name"), None), attack_name)
                    set_layer_text(next((l for l in basic_layer.layers if l.name == "BS_B_Description"), None), attack_info.get('Description', ''))
                    basic_dmg = int(dmg_value * basic_percentage)
                    set_layer_text(next((l for l in basic_layer.layers if l.name == "BS_B_DMG"), None), str(basic_dmg))

            elif attack_type == 'Special':
                special_layer = next((l for l in special_attack_group.layers if l.name == "Special"), None)
                if special_layer:
                    set_layer_text(next((l for l in special_layer.layers if l.name == "BS_S_Name"), None), attack_name)
                    set_layer_text(next((l for l in special_layer.layers if l.name == "BS_S_Description"), None), attack_info.get('Description', ''))
                    basic_dmg = int(dmg_value * 0.45)
                    special_dmg = dmg_value - basic_dmg
                    set_layer_text(next((l for l in special_layer.layers if l.name == "BS_S_DMG"), None), str(special_dmg))

def generate_cards(template_path, json_path, attacks_path, output_dir, character_images_dir, output_format):
    try:
        with open(json_path, 'r') as f:
            characters = json.load(f)

        with open(attacks_path, 'r') as f:
            attacks_data = json.load(f)

        ensure_directory_exists(output_dir)

        character_images, used_images_dir = get_character_images(character_images_dir)
        template_image = pdb.gimp_file_load(template_path, template_path)

        total_count = len(characters)

        for index, character in enumerate(characters, start=1):
            for name, data in character.items():
                card_image = pdb.gimp_image_duplicate(template_image)
                
                txt_group = next((l for l in card_image.layers if l.name == "TXT"), None)
                rarity_group = next((l for l in card_image.layers if l.name == "Rarity"), None)
                attacks_group = next((l for l in card_image.layers if l.name == "Attacks"), None)

                if txt_group:
                    stats = data.get('stats', {}).get(next(iter(data.get('stats', {}))), {})
                    dmg_value = update_text_layers(txt_group, name, stats, index, total_count)
                
                if rarity_group:
                    rarity = next(iter(data.get('stats', {})), 'Common')
                    show_rarity_layer(rarity_group, rarity)

                if attacks_group:
                    basic_attack_name = data.get('basic attack')
                    special_attack_name = data.get('special attack')
                    
                    has_basic = bool(basic_attack_name)
                    has_special = bool(special_attack_name)

                    if has_basic:
                        basic_attack_info = attacks_data.get('Basic', {}).get(basic_attack_name, {})
                        update_attack_layers(attacks_group, 'Basic', basic_attack_name, basic_attack_info, dmg_value)

                    if has_special:
                        special_attack_info = attacks_data.get('Special', {}).get(special_attack_name, {})
                        update_attack_layers(attacks_group, 'Special', special_attack_name, special_attack_info, dmg_value)
                    
                    show_attack_group(attacks_group, has_basic, has_special)

                image_key = "{} {}".format(name, rarity)
                if image_key in character_images and character_images[image_key]:
                    paste_character_image(card_image, character_images, name, rarity, character_images_dir)
                else:
                    print("No image available for {} {}".format(name, rarity))

                output_filename = "{}. {}.{}".format(index, name, output_format.lower())
                output_path = os.path.join(output_dir, output_filename)
                
                if output_format == 'PNG':
                    merge_layers(card_image)
                    pdb.file_png_save_defaults(card_image, card_image.active_layer, output_path, output_path)
                elif output_format == 'XCF':
                    pdb.gimp_xcf_save(0, card_image, card_image.active_layer, output_path, output_path)
                
                pdb.gimp_image_delete(card_image)
        
        pdb.gimp_image_delete(template_image)
    except Exception as e:
        print("An error occurred: {}".format(e))

register(
    "python-fu-generate-cards",
    "Generate cards from template",
    "Generate cards by modifying the template and exporting",
    "Sarah", "Sarah", "2024",
    "Generate Cards...",
    "",
    [
        (PF_FILE, "template_path", "Path to template XCF", ""),
        (PF_FILE, "json_path", "Path to character stats JSON", ""),
        (PF_FILE, "attacks_path", "Attack moves file", ""),
        (PF_FILE, "output_dir", "Output directory", ""),
        (PF_FILE, "character_images_dir", "Character images directory", ""),
        (PF_OPTION, "output_format", "Output format", "PNG", ["PNG", "XCF"])
    ],
    [],
    generate_cards
)

def main():
    pass

if __name__ == '__main__':
    main()
