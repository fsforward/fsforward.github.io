## Project File Management and Image Processing Guide

### **Important: Do NOT Remove or Move Project Files**

To ensure the project functions correctly, do not alter the location or remove any files that were originally included.

### **Image Requirements**

1. **Image Placement:**
   - Place all character images in the `Images` folder.

2. **Image Dimensions:**
   - Each image should have a resolution of **600x338 pixels** (width x height). This maintains a 16:9 aspect ratio.

3. **Naming Convention:**
   - Name your image files using the format: `X. NAME RARITY.png`
     - `X`: Sequential number (e.g., 1, 2, 3, etc.)
     - `NAME`: The name of the character. (NAME NEEDS TO BE THE SAME AS YOUR CARDS CHARACTER NAMES!)
     - `RARITY`: The rarity level of the character (e.g., Common, Rare, etc.)

   **Example:**
   - `1. Sarah Common.png`
   - `2. Sarah Common.png`
   - `1. fsForward Common.png`
   - `1. fsForward Uncommon.png`

   - Choose from the following rarity levels: Common, Uncommon, Rare, Epic, Legendary, Mythic, Godlike.

4. **Usage Tracking:**
   - Images will only be used once. After usage, they will be moved to the `Images\Used` folder.

### **Configuration Files**

1. **Rarity Settings:**
   - Modify rarity settings in `rarities.txt` as needed.

2. **Themes:**
   - Update or add new themes in `themes.json`. Note: Retaining the "pink" theme is recommended to avoid potential errors.

### **Using GIMP for Export**

1. **Image Preparation:**
   - Open 'scg.exe' (Sarah's Card Generator) and add names, attacks, and generate the stats for your images.

2. **Exporting Images:**
   - Go to the `Export` tab.
   - Select either `.PNG` or `.XCF` format.

3. **Executing Commands:**
   - Copy the export command.
   - Open GIMP and navigate to `Filters` -> `Python-Fu` -> `Console`.
   - Paste the command (CTRL + V) and press Enter.

4. **Finding Exported Files:**
   - Exported PNG or XCF files will be located in the `Cards` folder.

5. **Editing XCF Files:**
   - If you chose `.XCF`, you can edit the card further in GIMP.
   - When satisfied, convert the `.XCF` files to `.PNG` by repeating the export process but selecting 'XCF to PNG'.

6. **Final PNG Files:**
   - The converted PNG files will be available in `Cards\png`.

### **Summary**

- **Do NOT alter original files.**
- **Follow naming and dimension guidelines for images.**
- **Update settings and themes as needed.**
- **Use GIMP for exporting and editing images.**