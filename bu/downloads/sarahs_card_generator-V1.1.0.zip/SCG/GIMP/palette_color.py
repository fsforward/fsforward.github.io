# Generated with GIMP Palette Export
# Based on the palette Rarities
colors={
'Common': '#a9a9a9',
'Uncommon': '#32cd32',
'Rare': '#4169e1',
'Epic': '#008080',
'Legendary': '#00ffa4',
'Mythic': '#8a2be2',
'Godlike': '#ffff2a',
'Untitled': '#960000',
'Untitled': '#ffffff',
'Untitled': '#ff9600',
'Untitled': '#00ff00'}